#!/bin/bash -l

for p in {1..2}; do
 for k in {1,2}; do
    export OMP_NUM_THREADS=$p
    mpirun -np $k ./main 128 100 0.005 >> re128.csv
 done
done
